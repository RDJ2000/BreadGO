import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
LoginService
@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss']
})
export class AccountComponent implements OnInit {
  userDetails:any
  constructor(public LS:LoginService) { }

  ngOnInit(): void {
    this.userDetails=this.LS.getUser()
    console.log(this.userDetails);

  }



}
